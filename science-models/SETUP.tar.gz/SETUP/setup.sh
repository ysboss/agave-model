#!/bin/bash

#****Setup Folders, Files, and Variables for Plug-In****

BRC='
source ~/.bashrc-cmr

python3 $HOME/server/spack-reconfigure.py

if [ -d $SPACK_ROOT ]
then
    source $SPACK_ROOT/share/spack/setup-env.sh
fi'

UPSTR='
upstreams:
   spack-instance-1:
   install_tree: /spack/opt/spack
   modules:
      tcl: /spack/share/spack/modules'

echo "Parameters Set..."

#Placing .bashrc-cmr in Home Directory
if [ ! -f $HOME/.bashrc-cmr ]; then
   cp -n setupFiles/.bashrc-cmr $HOME/.bashrc-cmr
fi

#Set Environmental Variables in .bashrc
if !(grep -Fxq "$BRC" $HOME/.bashrc); then
   echo 'Configuring "~/.bashrc"...'
   echo "$BRC" >> $HOME/.bashrc
fi

# Make "exe" Directory
if [ ! -d "$HOME/exe" ]; then
   echo 'Creating "~/exe" directory...'
   mkdir $HOME/exe/
fi

# Make Data Directory
if [ ! -d "$CMR_DATA_DIR" ]; then
   echo 'Creating "~/cmr-data-dir" directory...'
   mkdir $CMR_DATA_DIR
fi

#Move Script Files to exe directory
if [ ! -f "$HOME/exe/getModelsPacks.sh" ] || [ ! -f "$HOME/exe/run-app.sh" ]; then
   echo 'Placing script file(s) in "exe" directory...'
   cp -n $PWD/setupFiles/*.sh $HOME/exe/
fi

#Install plug-in server files for user
if [ ! -d "$HOME/server" ]; then
   echo	'Installing Plug-In...'
   tar -xvf $PWD/setupFiles/plug-in.tar.gz -C $HOME/
fi

#Set the Spack Upstream
if [ -d $SPACK_ROOT ]; then
   touch $HOME/.spack/upstreams.yaml
   if !(grep -Fxq "$UPSTR" $HOME/.spack/upstreams.yaml); then
      echo 'Configuring "~/.spack/upstreams.yaml"...'
      echo "$UPSTR" >> $HOME/.spack/upstreams.yaml
   fi
fi

#Install Local Spack
if [ ! -d "$SPACK_ROOT" ] && [ -z "$SPACK_ROOT" ]; then
   echo 'Installing Spack...'
   git clone https://github.com/spack/spack.git $SPACK_ROOT
   HERE=$PWD
   cd $SPACK_ROOT/bin
   ./spack install zlib
   cd $HERE
fi

echo "Plug-In files successfully installed on the server!"
echo 'Please refer to the "~/server" directory for installing models'
