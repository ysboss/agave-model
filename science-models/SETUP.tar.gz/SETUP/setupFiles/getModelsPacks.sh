#!/bin/bash
singularity exec $SING_OPTS $IMAGE bash -l ~/exe/getModelsPacksFromImage.sh
