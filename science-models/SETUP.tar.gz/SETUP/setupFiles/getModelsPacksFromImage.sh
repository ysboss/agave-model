#!/bin/bash

if [ -r input.tgz ]
then
    tar -xvf input.tgz
fi
if [ -d run_dir ]
then
    cd run_dir
fi
mkdir -p machineFiles
for d in /JSONFiles ~/build-dir/json
do
    if [ -d $d ]
    then
        cp $d/* machineFiles
    fi
done
spack find > machineFiles/spack-info.txt
tar -czvf machineFiles.tar.gz machineFiles
