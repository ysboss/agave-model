#!/bin/bash

# Save the current directory
singularity exec $SING_OPTS $IMAGE bash -c 'tar -xvf input.tgz ;
cd run_dir ;
echo $PWD ;
source ./env.sh ;
source $SPACK_ROOT/share/spack/setup-env.sh ;
model_w_ver=${model^^} ;
model_w_ver+="_VER" ;
spack compiler find ;
spack load ${model}@${!model_w_ver} ;
spack load mpich@${MPICH_VER} ;
echo "Job is: $PBS_JOBID" ;
echo "Mom is: $(hostname)" ;
echo "Running from $(pwd)" ;
JSONFILE=/build-dir/json/${model}-${!model_w_ver}.json ;
nx=$(jq .nx ${JSONFILE}) ;
ny=$(jq .ny ${JSONFILE}) ;
nz=$(jq .nz ${JSONFILE}) ;
NP=$((${nx}*${ny}*${nz})) ;
INPUTFILE=$(jq .inputFile ${JSONFILE}) ;
if [ -z "$INPUTFILE" ];
then
    perl -p -i -e "s/^[ \t]*PX[ \t]*=[ \t]*\d+[ \t]*$/PX=$nx/" $INPUTFILE ;
    perl -p -i -e "s/^[ \t]*PY[ \t]*=[ \t]*\d+[ \t]*$/PY=$ny/" $INPUTFILE ;
fi ;
mpirun -np "${NP}" ${model}'
