from subprocess import Popen, PIPE
import re
import glob
import json
import os, sys

class HiddenPrint:
    def __enter__(self):
        self._original_stdout = sys.stdout
        #self._original_stderr = sys.stderr
        sys.stdout = open("spack-log.txt", 'w')
        #sys.stderr = open("spack-log.txt", 'a')

    def __exit__(self, exc_type, exc_val, exc_tb):
        sys.stdout.close()
        #sys.stderr.close()
        sys.stdout = self._original_stdout
        #sys.stderr = self._original.stderr

def gen_spack_pack_list():
    print("Retrieving Model Versions List...")
    os.system("mkdir -p run_dir")
    os.system("rm -f run_dir/*")

    with open("run_dir/get-versions.sh","w") as v:
        print("#!/bin/bash", file=v)
        print("source $SPACK_ROOT/share/spack/setup-env.sh", file=v)
        print("spack find > /build-dir/spack-info.txt", file=v)
    os.system("chmod 755 run_dir/get-versions.sh")
    with open("run_dir/runapp.sh","w") as fd:
        print("run_dir/get-versions.sh", file=fd)
    os.system("chmod 755 run_dir/runapp.sh")

    os.system("run_dir/runapp.sh")
    print("Done!")


def tarballHandler(tarName):
    installedPath = "%s/models" % os.environ["PWD"]
    folderName = tarName.split('.t')
    # Split the tarball's name according to '.t' since all
    # tarball extensions begin with 't'
    # Ideally, the tarball will be named "model-version.tar/.tgz/.tar.gz"
    # JSON files should have a similar naming convention: model-version.json
    os.system("mkdir -p %s/%s" % (installedPath, folderName[0]))
    os.system("tar -xvf %s/models_to_install/%s -C %s/%s/" % (os.environ["PWD"], tarName, installedPath, folderName[0]))
    os.system("cp %s/%s/* /build-dir/tarballs" % (installedPath, folderName[0]))
    os.system("mv /build-dir/tarballs/*.json /build-dir/json/")
    os.system("mkdir -p %s/%s/tarball" % (installedPath, folderName[0]))
    os.system("mv %s/models_to_install/%s %s/%s/tarball/" % (os.environ["PWD"], tarName, installedPath, folderName[0]))
    untar_path = installedPath+'/'+folderName[0]
    # Source code tar name should be determined when writing package.py file
    # Extracted files should be a tarball of the source code
    # for the model and a JSON file containing model details
    return untar_path
#Function to handle untar-ing user's tarballs



def cleanup(modelPath):

       os.system("rm %s/*.tar %s/*.tar.gz %s/*.tgz 2>/dev/null" % (modelPath, modelPath, modelPath))
       os.system("mv %s/tarball/* %s/tarball/.." % (modelPath, modelPath))
       os.system("rm -r %s/tarball" % modelPath)
# Removes the Source Code Tar and organizes the original file into the root of
# the respective model folder



def installNewModels():
    
        newModelsPath = os.environ["PWD"]+"/models_to_install"


        if len(glob.glob(os.path.join(newModelsPath, '*'))) != 0:
            print("Looking for New Models to Build...")
            os.system("mkdir -p /build-dir/tarballs/")
            os.system("mkdir -p /build-dir/json")
            os.system("mkdir -p models")
 
            spackPackList = []

            # Here, we make a list of all the models to be installed according
            # to their respective spack package
            for tarball in glob.glob(os.path.join(newModelsPath, '*')):
                if os.path.isfile(tarball):
                    modelSetupPath = tarballHandler(os.path.basename(tarball))
                    splitTarball = os.path.basename(tarball).split(".t")
                    with open("%s/%s.json" % (modelSetupPath, splitTarball[0].lower())) as f:
                        modelJSON = json.load(f)
                    print("New Model Found and Preparing to Install: %s (%s@%s)" % (modelJSON["name"], modelJSON["package"], modelJSON["version"]))
                    spackPackList.append(modelJSON["package"]+'@'+modelJSON["version"])
                    # Additionally, we move a copy of the tarball of the
                    # model's source code (in a tar also) to the run_dir so it can be placed
                    # on the server in the proper tarball directory (if needed)
                    cleanup(modelSetupPath)

            print("Installing New Model(s). This may take awhile...")

            os.system("mkdir -p run_dir")
            os.system("rm -f run_dir/*")

            with open("run_dir/build-models.sh","w") as v:
                print("#!/bin/bash", file=v)
                #print("source /build-dir/ubuntu_xenial/spack/share/spack/setup-env.sh", file=v) # Need to make more generic
                for pack in range(len(spackPackList)):
                    buildCommand = "spack install " + spackPackList[pack]
                    print(buildCommand, file=v)
            os.system("chmod 755 run_dir/build-models.sh")

            with open("run_dir/runapp.sh","w") as fd:

                #print("singularity exec $SING_OPTS --pwd "+os.environ["PWD"]+" $IMAGE bash ./tarballs.sh", file=fd)
                #print("singularity exec $SING_OPTS --pwd "+os.environ["PWD"]+" $IMAGE bash -l ./build-models.sh", file=fd)

                print("run_dir/build-models.sh", file=fd)
            os.system("chmod 755 run_dir/runapp.sh")

            os.system("run_dir/runapp.sh")
            gen_spack_pack_list()
            os.system("rm -rf run_dir/")

        else:
            print("No New Models Found!")


installNewModels()
